console.log('=================================  TYPE COERCION  ==================================');

console.log(true == 1);

console.log(true - false == 1);

console.log(true - false === 1);

console.log("2" + 2);

console.log("2" - 2);

console.log("2" - - 2);

console.log("" == 0);

console.log(undefined == null);

console.log("0" == 0);

console.log("false" == false);

// console.log("ba" + + "a" + "a");

console.log('====================================================================================');
