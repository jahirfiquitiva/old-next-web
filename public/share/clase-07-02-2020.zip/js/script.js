console.log('Hola Mundo!');
console.log('======================= IF - TERNARY OPERATOR - SWITCH =============================');

const hour = new Date().getHours();

if (hour < 12) {
    console.log('Antes de las 12 pm')
} else {
    console.log('Después de las 12 pm')
}

console.log(hour < 12 ? 'Ternary -> Antes de las 12 pm' : 'Ternary -> Después de las 12 pm');

switch (hour) {
    case 1:
        console.log('Es la 1');
        break;
    case 2:
        console.log('Son las 2');
        break;
    default:
        console.log('No es la 1 ni las 2');
        break;
}

console.log(`La hora es ${hour}`);

console.log('====================================================================================');
