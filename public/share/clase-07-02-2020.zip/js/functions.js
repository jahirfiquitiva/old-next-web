function logSomething() {
    console.log('Something');
}

function logThis(text = 'Hola') {
    console.log(text);
}
