document.getElementById('secondary-button').addEventListener('click', (e) => {
    logThis('Secondary button clicked');
});

const newElement = document.createElement('h2');
newElement.innerText = 'h2 creado en JS';
document.body.appendChild(newElement);

const newDiv = document.createElement('div');
newDiv.innerHTML = '<p>Div creado en JS</p>';
newDiv.classList.add('my-div');
document.body.appendChild(newDiv);

const newText = document.createTextNode('Nuevo texto');
try {
    newText.classList.add('my-new-text');
} catch (e) {
    console.error(e);
}
newDiv.appendChild(newText);
