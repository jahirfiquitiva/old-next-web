console.log('==================================     LOOPS     ===================================');

const list = ['a', 'b', 'c', 'd', 'e'];

console.log('For In List');
for (let item in list) {
    console.log(item);
}

console.log('For Of List');
for (let item of list) {
    console.log(item);
}

const object = {a: '1', b: '2', c: '3'};

console.log('For In Object');
for (let item in object) {
    console.log(item);
}

console.log('For Of Object');
try {
    for (let item of object) {
        console.log(item);
    }
} catch (e) {
    console.error(e);
}

console.log('While');
let i = 5;
while (i >= 0) {
    console.log(`i is ${i}`);
    i -= 1;
}

console.log('For Each');
list.forEach((value, index, array) => {
    console.log(`Value at index [${index}] is -> ${value}`);
    console.log(array.join(','))
});

console.log('====================================================================================');
